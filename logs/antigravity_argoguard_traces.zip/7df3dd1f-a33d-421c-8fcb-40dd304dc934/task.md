# Task - Real-Time Weather Integration

## Backend
- [x] Create `weather_service.js` (Open-Meteo integration + farming recommendations)
- [x] Create `weather_controller.js`
- [x] Create `weather_routes.js`
- [x] Modify `app.js` to mount `/weather` route

## Frontend (Flutter)
- [x] Create `weather_model.dart`
- [x] Create `weather_provider.dart`
- [x] Modify `api_service.dart` (add `getWeather()`)
- [x] Modify `main.dart` (register WeatherProvider)
- [x] Modify `dashboard_screen.dart` (add Weather Card + location selector)

## Verification
- [ ] Test backend `/weather` endpoint with curl
- [ ] Run backend integration tests (no regressions)
