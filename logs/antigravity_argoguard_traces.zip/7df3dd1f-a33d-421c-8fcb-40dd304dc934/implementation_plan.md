# Implementation Plan - Real-Time Weather Integration

Introduce a real-time, location-aware weather forecast feature in ArgoGuard AI. This feature will fetch real-time meteorological data and provide actionable agricultural recommendations to the farmer (e.g., whether to irrigate or pesticide spray based on precipitation probability).

## Proposed Architecture

```mermaid
graph TD
    A[Flutter App: Dashboard] -->|GET /weather?lat=X&lon=Y| B[Express Backend]
    B -->|Query Weather API| C[Open-Meteo API]
    C -->|Meteorological Data| B
    B -->|Resolve Ag-Recommendations| B
    B -->|Weather + Actionable Advice JSON| A
```

- **Weather Data Source**: Open-Meteo (Free, keyless, high-precision public weather service).
- **Location Detection**:
  - The Flutter client will pass latitude/longitude coordinates.
  - For testing/simulation ease, the client will default to Faisalabad, Pakistan (`31.4504, 73.1350`), a major agricultural hub, and allow changing the location via a quick-selector.
- **Agricultural Recommendations (AI-powered / Rules-based)**:
  - **High Winds (>20 km/h)**: "High wind warning! Suspend drone pesticide spraying."
  - **High Probability of Rain (>50%)**: "Rain expected soon! Suspend scheduled irrigation."
  - **Clear/Sunny (Weathercode 0-3)**: "Ideal weather for crop inspection and harvesting."
  - **Extreme Hot (>38°C)**: "High temperature alert! Monitor crop moisture levels."

---

## Proposed Changes

### Backend (Express)

#### [NEW] [weather_service.js](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/backend/src/services/weather_service.js)
- Implements fetch logic to query Open-Meteo.
- Implements interpretation logic for weather codes.
- Implements rule-based farmer recommendations.

#### [NEW] [weather_controller.js](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/backend/src/controllers/weather_controller.js)
- Validates query params `latitude` and `longitude`.
- Invokes weather service and formats responses.

#### [NEW] [weather_routes.js](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/backend/src/routes/weather_routes.js)
- Exposes route `GET /weather` protected by auth middleware.

#### [MODIFY] [app.js](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/backend/src/app.js)
- Mounts `/weather` route.

---

### Frontend (Flutter)

#### [NEW] [weather_model.dart](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/lib/models/weather_model.dart)
- Model representing temperature, weather description, wind speed, precipitation probability, location name, and agricultural recommendations.

#### [NEW] [weather_provider.dart](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/lib/providers/weather_provider.dart)
- Manages loading state, active coordinates, and fetched weather data.

#### [MODIFY] [api_service.dart](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/lib/services/api_service.dart)
- Adds `Future<WeatherModel> getWeather(double lat, double lon)` endpoint calling the `/weather` backend route.

#### [MODIFY] [main.dart](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/lib/main.dart)
- Registers `WeatherProvider` in the MultiProvider block.

#### [MODIFY] [dashboard_screen.dart](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/lib/ui/screens/dashboard_screen.dart)
- Integrates a beautiful, glassmorphic Weather Card on the dashboard dashboard showing current conditions and farming advice.
- Provides a location selector dropdown (Faisalabad, Multan, California, Iowa, London) to dynamically change location and fetch live weather.

---

## Verification Plan

### Automated/Unit Tests
- Verify backend API returns 200 and correct weather JSON structure: `curl http://localhost:5000/weather?latitude=31.4504&longitude=73.1350`
- Run backend integration test suite to ensure no regressions.

### Manual Verification
- Test location-selector on Dashboard UI and observe real-time changes in temperature, description, and farming recommendations.
