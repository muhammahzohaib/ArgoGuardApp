# Implementation Plan: OTP Verification & Social Authentication

Add OTP-based authentication (One-Time Password) and social login (Google, Facebook, Twitter/X) to the AgroGuard AI system. This plan details the required user interface upgrades, state providers, API integrations, and backend controllers, including high-fidelity simulation modes.

## User Review Required

> [!IMPORTANT]
> The current auth system is configured with a rich demonstration mode. We will build both a high-fidelity simulation and live backend integration hooks for both OTP validation and Social Login so that the app remains testable immediately even without additional server setup (e.g. Firebase setup).

## Proposed Changes

---

### [Component 1] Flutter Authentication UI & Logic (Client)

#### [NEW] [otp_screen.dart](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/lib/ui/screens/auth/otp_screen.dart)
Create a new, highly premium OTP verification screen:
* Sleek card-based modern design featuring HSL Tailwind-style greens and subtle animations.
* Custom 6-digit OTP input using segmented fields that auto-focus next on input.
* Interactive Resend Timer with cooldown animation.
* Fully connected to the `AuthProvider` for validation.

#### [MODIFY] [login_screen.dart](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/lib/ui/screens/auth/login_screen.dart)
* Add a tab/switch to choose between **"Email & Password"** and **"Email & OTP"** login methods.
* Add a beautiful **"Or Sign In With"** divider.
* Add three premium Social Login buttons:
  * **Google** (Sleek card button)
  * **Twitter (X)** (Modern dark card button)
  * **Facebook** (Classic blue-tinted modern button)
* Social buttons will feature smooth tap animations.

#### [MODIFY] [register_screen.dart](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/lib/ui/screens/auth/register_screen.dart)
* Add the **"Or Sign Up With"** divider and the social login buttons.
* If registering with email, redirect to the OTP verification screen before logging in.

#### [MODIFY] [routes.dart](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/lib/core/routes.dart)
* Add the `/otp` route mapped to `OtpScreen`.

#### [MODIFY] [api_service.dart](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/lib/services/api_service.dart)
* Add client request hooks for:
  * `sendOtp(String email)`
  * `verifyOtp(String email, String code)`
  * `socialLogin(String provider, String token)`
* Ensure full high-fidelity simulation fallback when backend is offline:
  * `sendOtp` simulates delivering an OTP (logs to console/debug console).
  * `verifyOtp` accepts `123456` or any matching demonstration code, then logs in successfully.
  * `socialLogin` generates rich mock profile data for each provider.

#### [MODIFY] [auth_provider.dart](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/lib/providers/auth_provider.dart)
* Expose `sendOtp`, `verifyOtp`, and `socialLogin` methods to wrap `ApiService`.
* Store temporary user context while OTP verification is pending.

---

### [Component 2] NodeJS Authentication Endpoints (Backend)

#### [MODIFY] [auth_routes.js](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/backend/src/routes/auth_routes.js)
* Add routes for:
  * `POST /auth/send-otp`
  * `POST /auth/verify-otp`
  * `POST /auth/social-login`

#### [MODIFY] [auth_controller.js](file:///Users/muhamadzohaib/Downloads/ArgoGuardAi/backend/src/controllers/auth_controller.js)
* Implement OTP generation (using 6-digit random codes) and store them in an in-memory/temp map with standard 5-minute expiration times.
* Implement OTP verification: on success, find or create the user, then issue a JWT token.
* Implement Social Login controller: verify social tokens or mock-validate them, find/create the associated user record, and return the token.

---

## Verification Plan

### Automated & Manual Verification
1. **Demo Mode (No Server):**
   * Run the Flutter app.
   * Go to Login/Register, tap social login buttons, confirm that you are successfully logged in using simulated profiles.
   * Switch to OTP login, type an email, tap "Send OTP", verify you are redirected to the OTP screen. Enter standard test OTP `123456` and verify dashboard entrance.
2. **Live Mode (With Server):**
   * Start backend (`npm run dev`).
   * Test the network calls for `send-otp`, `verify-otp`, and `social-login` using client logs.
