# Tasks: OTP Verification & Social Authentication

- `[x]` Update client routing in `lib/core/routes.dart` to include `/otp`
- `[x]` Implement OTP verification screen `lib/ui/screens/auth/otp_screen.dart` with modern visuals
- `[x]` Add API endpoints and simulated fallbacks to `lib/services/api_service.dart`
- `[x]` Add state methods and login options in `lib/providers/auth_provider.dart`
- `[x]` Update `lib/ui/screens/auth/login_screen.dart` with social logins and OTP option
- `[x]` Update `lib/ui/screens/auth/register_screen.dart` to redirect to OTP and show social buttons
- `[x]` Add OTP and social authentication endpoints to Node.js backend routes `backend/src/routes/auth_routes.js`
- `[x]` Implement OTP generation/validation and social auth in `backend/src/controllers/auth_controller.js`
- `[x]` Verify frontend UI and backend services
