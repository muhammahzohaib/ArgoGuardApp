# Implementation Plan: 6-Agent Orchestration System for AgroGuard AI

This plan outlines the restructuring and development of a robust **Multi-Agent Orchestration System** inside the backend. It implements 6 distinct, communicating agents, supports retry & rollback logic, tracks execution logs (observation, reasoning, action, outcome, recovery), and manages shared pipeline state.

## User Review Required

> [!IMPORTANT]
> - **Orchestration file**: We will overwrite/refactor `backend/src/agents/multi_agent_orchestrator.js` to implement this comprehensive 6-agent pipeline.
> - **State Integration**: Shared state will track parameters dynamically as they flow from the Input Aggregation Agent down to the Action Execution and Recovery Agents.

## Proposed Changes

### 1. Agents Registry & Communication Workflow
We will implement 6 specialized agents in `backend/src/agents/multi_agent_orchestrator.js`:
1. **Input Aggregation Agent**: Accumulates visual crop files, weather feeds, and physical sensor data.
2. **Disease Analysis Agent**: Runs Gemini/Pathogen diagnostic matchers to identify symptoms and confidence.
3. **Risk Assessment Agent**: Calculates crop spread risk, urgency level, and danger metrics.
4. **Constraint Planning Agent**: Identifies environmental conflicts (calling `contradiction_service.js`) and compiles action constraints.
5. **Action Execution Agent**: Executes chain dispatches (e.g. drone chemical dispatch). Integrates retry loops (up to 3 times).
6. **Recovery Agent**: Triggers fallback procedures (e.g. warning notifications, system safe-state rollback) if actions fail.

### 2. Execution Log Schema
Each agent action compiles logs adhering to:
* `observation`: Data ingested by the agent.
* `reasoning`: Cognitive evaluations and choices.
* `action`: Commenced changes or API queries.
* `outcome`: Resulting output data.
* `recovery` *(optional)*: Actions taken during self-correction or rollbacks.

---

## Verification Plan

### Automated Tests
* Update `backend/test/backend.test.js` to trigger a multi-agent orchestration analysis.
* Assert that the response contains:
  * Six agents executing in sequence.
  * Structured logs including `observation`, `reasoning`, `action`, and `outcome`.
  * Successful retry triggers when simulated failures are injected.
  * Safe rollbacks managed by the Recovery Agent when actions fail permanently.
